import { cn } from '../lib/cn';

interface HeaderProps {
  solved: number;
  streak: number;
  seconds: number;
}

function formatClock(seconds: number): string {
  const minutes = Math.floor(seconds / 60).toString().padStart(2, '0');
  const rest = (seconds % 60).toString().padStart(2, '0');
  return `${minutes}:${rest}`;
}

function Stat({ label, value, accent = false }: { label: string; value: string; accent?: boolean }) {
  return (
    <div className="min-w-[66px] rounded-xl border border-white/10 bg-white/[0.04] px-3 py-1.5 text-center backdrop-blur">
      <div className="text-[10px] tracking-[0.18em] text-slate-500">{label}</div>
      <div
        className={cn(
          'font-mono text-base font-semibold tabular-nums transition-colors',
          accent ? 'text-neon' : 'text-slate-100',
        )}
      >
        {value}
      </div>
    </div>
  );
}

export function Header({ solved, streak, seconds }: HeaderProps) {
  return (
    <header className="flex items-end justify-between gap-3">
      <div>
        <div className="flex items-baseline gap-1">
          <span className="bg-gradient-to-b from-white via-white to-slate-500 bg-clip-text font-mono text-[34px] font-extrabold leading-none tracking-tight text-transparent">
            24
          </span>
          <span className="text-sm font-semibold text-neon">点</span>
        </div>
        <p className="mt-1 text-[11px] tracking-[0.22em] text-slate-500">MAKE IT 24</p>
      </div>

      <div className="flex gap-2">
        <Stat label="已解" value={String(solved)} />
        <Stat label="连击" value={String(streak)} accent={streak > 0} />
        <Stat label="用时" value={formatClock(seconds)} />
      </div>
    </header>
  );
}
