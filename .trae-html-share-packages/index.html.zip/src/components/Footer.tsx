interface FooterProps {
  onNew: () => void;
}

const Dot = () => <span className="h-[3px] w-[3px] rounded-full bg-white/20" />;

export function Footer({ onNew }: FooterProps) {
  return (
    <footer className="flex flex-wrap items-center gap-x-3 gap-y-2 text-xs text-slate-500">
      <span>四个数字各用一次</span>
      <Dot />
      <span>只用 + − × ÷ 与括号</span>
      <Dot />
      <span>回车提交</span>
      <button
        type="button"
        onClick={onNew}
        className="ml-auto rounded-lg border border-white/10 px-3 py-1.5 text-xs text-slate-300 transition hover:border-neon/50 hover:text-neon"
      >
        换一题
      </button>
    </footer>
  );
}
