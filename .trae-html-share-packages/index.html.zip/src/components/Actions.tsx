interface ActionsProps {
  disabled: boolean;
  onHint: () => void;
  onAnswer: () => void;
  onSubmit: () => void;
}

export function Actions({ disabled, onHint, onAnswer, onSubmit }: ActionsProps) {
  return (
    <div className="grid grid-cols-[1fr_1fr_1.6fr] gap-2">
      <button
        type="button"
        onClick={onHint}
        disabled={disabled}
        className="h-12 rounded-xl border border-white/10 text-sm text-slate-400 transition hover:border-white/25 hover:text-white disabled:cursor-default disabled:opacity-40"
      >
        提示
      </button>
      <button
        type="button"
        onClick={onAnswer}
        disabled={disabled}
        className="h-12 rounded-xl border border-white/10 text-sm text-slate-400 transition hover:border-white/25 hover:text-white disabled:cursor-default disabled:opacity-40"
      >
        看答案
      </button>
      <button
        type="button"
        onClick={onSubmit}
        disabled={disabled}
        className="h-12 rounded-xl bg-neon text-sm font-semibold text-ink-950 shadow-[0_12px_36px_-12px_rgba(62,224,161,0.8)] transition hover:bg-[#54e9b0] active:scale-[0.98] disabled:cursor-default disabled:opacity-50 disabled:shadow-none"
      >
        提交
      </button>
    </div>
  );
}
